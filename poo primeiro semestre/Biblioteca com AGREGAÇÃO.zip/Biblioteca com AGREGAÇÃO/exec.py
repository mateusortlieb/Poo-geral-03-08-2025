from livro import Livro
from Aluno import Aluno
from AlunoPremium import Alunovip

# aluno1 = Aluno('239', 'Mateus', 'Ortlieb', '11023976951')
# livro1 = Livro('123', 'mentiras', 'eu', 'eutbm', 'Indisponível', '2023', aluno1)
# aluno2 = Aluno('434', 'Cesco', 'Fransce', '29496846582')
# livro2 = Livro('555', 'falcatruas', 'my', 'aqueles', 'Indisponível', '2025', aluno2)
pedro = Alunovip('333', 'lara', 'pedro', '101010', '123', 'a mais barata', '30 anos')

# livro1.emprestar(aluno2)
# livro1.emprestar(aluno1)
# livro1.emprestar(aluno2)
# livro1.devolver()
# livro1.historico.imprime()
# print("\n\n\n")
# print(livro1.get_nome())
# print(aluno1.get_nome())

pedro.autentica('123')


